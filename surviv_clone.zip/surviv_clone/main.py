from Window import Window


window = Window()
window.start()

